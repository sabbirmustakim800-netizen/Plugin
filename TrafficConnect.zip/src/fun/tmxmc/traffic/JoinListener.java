package fun.tmxmc.traffic;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

public class JoinListener implements Listener {

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        TrafficConnect plugin = TrafficConnect.getInstance();
        FileConfiguration config = plugin.getConfig();

        String siteUrl = config.getString("website-url", "https://fuckabir.tmxmc.fun");

        // ১. বেডরক (Bedrock / Mobile) প্লেয়ার চেক
        boolean isFloodgateEnabled = Bukkit.getPluginManager().isPluginEnabled("Floodgate");
        
        if (isFloodgateEnabled && FloodgateApi.getInstance().isFloodgatePlayer(player.getUniqueId())) {
            
            int delay = config.getInt("bedrock.delay-ticks", 40);
            
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;

                    String title = config.getString("bedrock.title", "WELCOME");
                    String content = config.getString("bedrock.content", "Click below to play!");
                    String btnText = config.getString("bedrock.button-text", "PLAY NOW");

                    SimpleForm form = SimpleForm.builder()
                            .title(title)
                            .content(content)
                            .button(btnText)
                            .validResultHandler((f) -> {
                                // বাটনে চাপলে কমান্ড এক্সিকিউট হবে
                                player.performCommand("geyser url " + siteUrl);
                            })
                            .build();

                    FloodgateApi.getInstance().sendForm(player.getUniqueId(), form);
                }
            }.runTaskLater(plugin, delay);

            return; // বেডরক প্লেয়ার হলে এখানেই শেষ
        }

        // ২. জাভা (Java / PC) প্লেয়ারদের চ্যাট মেসেজ
        String javaMsg = config.getString("java.join-message", "Click here to play!");
        TextComponent message = new TextComponent(javaMsg);
        message.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, siteUrl));

        player.spigot().sendMessage(message);
    }
}
