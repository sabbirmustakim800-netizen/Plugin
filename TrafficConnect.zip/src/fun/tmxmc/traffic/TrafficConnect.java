package fun.tmxmc.traffic;

import org.bukkit.plugin.java.JavaPlugin;

public class TrafficConnect extends JavaPlugin {

    private static TrafficConnect instance;

    @Override
    public void onEnable() {
        instance = this;

        // config.yml সেভ ও লোড করা
        saveDefaultConfig();

        // ইভেন্ট লিসেনার রেজিস্টার করা
        getServer().getPluginManager().registerEvents(new JoinListener(), this);

        getLogger().info("TrafficConnect Plugin successfully enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TrafficConnect Plugin disabled.");
    }

    public static TrafficConnect getInstance() {
        return instance;
    }
}
